import UIKit

// MARK: Enumerations
/* Swift enumerations allows us to keep realted values togethe into a group that we can use and access.
 Like switch statements, each value in enum is considered a different case. Which is one of the many reasons switch statemtnts and enum goes well together.
 */


/* Enumerations can be expanded to include raw values, which can store unique or sequential values, OR
 Associated values, which can capture case specific parameters for use in their respective code blocks.
 
 */


// raw values
enum NonPlayableCharacters: String {
    case Villager = "Commo, not much useful info there"
    case Blacksmith = "One per village, will have quest information"
    case Merchant = "Will make you coll stuffs"
}

var blacksmith = NonPlayableCharacters.Blacksmith
print(blacksmith.rawValue)

// IF we change raw value type to Int, we can see that blacksmith is going to be raw value of 1 as per its index.


// Associated Value

enum PlayerState{
    case Alive
    case KO(level: Int) // it is like passing parameter to function
    case Unknown(debugError: String)
    
    // Enumerations can have properties and methods of their own.
    // This feture is perfect for creating class like behaviour for situations with finite options.
    
    // adding a new function inside the enum declaration.
    func evaluateCase(){
        
        // Since this function is inside the enum declaration, we can have the enum switch in itself using self keyword.
        
        switch self {
        case .Alive:
            print("Still kicking")
        case .KO(let restartLevel):
            print("Back to \(restartLevel) level for you")
        case .Unknown(let message):
            print(message)
        default:
            print("Unknown state encountered...")
            
        }
    }
}



PlayerState.KO(level: 1).evaluateCase()

PlayerState.Unknown(debugError: "Message for unknown error").evaluateCase()
// Our associated value was captured, passed into function and used in case statement.

// Because of inflexiblity of enums in other languages they are less utilized, Be sure to take advantage of enums in swift language.









