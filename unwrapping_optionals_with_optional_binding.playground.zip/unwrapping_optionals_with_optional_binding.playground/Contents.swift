// Test Variables
var itemgathered: String? // an optional String
var isShopOpen: Bool?  // an optional Boolean

// A dictionary with key value pairs
var blacksmithShop: [String: Int] = ["Bottle": 10, "Shield": 15, "Ocarina": 100]

// A Nested Dictionary
var questDirectory = [
    "Fetch Gemstones": [
        "Objective": "Retrive 5 gemstones",
        "Secret": "Complete in under 5 minutes"
    ],
    "Defeat GodFather": [
        "Objective": "Beat the Godfather",
        "Secret": "Win with 50% health remaining"
    ]
]

// Optional Binding

// Unwrapping the itemgathered



// We are saying if itemGathered is not nil, unwrap the value and assign it to item, which we can use in the body of if statement.
if let item = itemgathered {
    print("You found an item \(item)")
    // the unwrapped optional value item is only accessible within the if statement, tyring to reference it anywhere else will come up as blank in auto complete.
    // Here, item is nil right now, nothing is going to execute and our program will not crash like it did with force unwrapping.
} // add an else statement to easily handle the nil value
else{
    print("Sorry no item found")
}

// For Multiple Optionla Binding both of them have to be true
if let shopOpen = isShopOpen, let searchedItem = blacksmithShop["Shield"]{
    print("we're open \(shopOpen) and we have \(searchedItem) in stock!")
    
} else {
    print("Sorry, either we're not open or we don't have the item.")
}

// unwrapping one of our objectives safely

if let fetchGems = questDirectory["Fetch Gemstones"]?["Objective"]{ // fetch gemstones is an optional, it might not exist, we are not sure about its existance. If it exists, we want to query the objective with in
    // if we find this quest we what to print the active quest object i.e fectch Gems a local variable
    print("Active quest object : \(fetchGems)")
}else {
    print("That quest is no longer available")
}
