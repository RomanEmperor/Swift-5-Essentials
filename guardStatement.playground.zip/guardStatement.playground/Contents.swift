// MARK: - Guard Statement

// Some test variables
let shopItems = ["Pencil": 120, "Cover": 69, "Earpods": 199,
                 "Mouse": 123]
let currentGold = 85

for (item, price) in shopItems {
    guard currentGold >= price else {
        print("You can't afford these items \(item)")
        continue
    }
    print("Go ahead the item \(item) is yours for the price \(price)")
}

