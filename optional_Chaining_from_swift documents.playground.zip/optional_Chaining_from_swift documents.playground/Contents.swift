import UIKit

/**
Optional Chaining:
Optional Chaining is a procress for querying and calling
    - properties
    - methods
    - subscripts
 on an optional that currently be nil.
 If the optional contains a value, the property, method, or subscript call succeeds;
 if the optional is nil, the property, method, or subscript call returns nil.
 
 Multiple queries can be chained together, and the entire chain
 fails gracefully if any link in the chain is nil.
 
 Forced Unwrapping
 Optional chaining fails gracefully when the optional is nil,
 whereas forced unwrapping triggers a runtime error when the
 optional is nil.
 
 **/
class Person{
    var name: String?
    var phoneNumber: Int?
    var email: String?
    var residence: Residence?
}

class Residence{
    var numberOfRooms = 3
}

// creating instance of class Person
let john = Person()


john.name = "Johnson Johnson"
john.email = "johnson&johnson@email.com"

// Assigining Residence instance to john; if not created, person class instance "john" doesnot have access to "Residence" class properties.
john.residence = Residence()

// Nested Optional unwrapping
if let userName = john.name{
    print("User has a userName \(userName)")
    // Nested optional unwrapping
    if let useremail = john.email{
        print("User email is also available: \(useremail)")
    }else{
        print("There is no userEmail, Only UserName is available.")
    }
}else{
    print("User has no User Name")
}

// Optional Chaining

if let roomCount = john.residence?.numberOfRooms{ // this tells swift to chain on the optional residence property and to retrive the value of numberOfRooms if residence exists.
    
    print("John's residense has \(roomCount) rooms")
}else{
    print("couldn't find room counts of john's residence")
}


