import UIKit

// MARK: Enumerations
/* Swift enumerations allows us to keep realted values togethe into a group that we can use and access.
 Like switch statements, each value in enum is considered a different case. Which is one of the many reasons switch statemtnts and enum goes well together.
 */


// Declaring an enum
enum GameState {
    case Completed, Initalizing, LoadingData
    case newCase
}

// Storing and switching on an enum value

var currentState = GameState.newCase

print("Current game state: \(currentState)")

// using switch statement with enum
// ** rememeber switch statement is exhaustive meaning, all the possible cases must be defined explicitly.

switch currentState {
case .Completed:
    print("Completed procressing all tasks....")
    
case .Initalizing:
    print("Initalizing process on the go...")
    
case .LoadingData:
    print("Loading data from the internet...")
    
    // TEchnically, a switch statement being used with an enum doesn't need a default case BECAUSE enum only allows a constant number of options i.e they are all known.
    // However if we want to add a case in future, compiler will throwUp an error.
    // So, to avoid manually updating switch statement every time you provide a new case, use @unknown default
    // Be aware of warning though !!
    
@unknown default:
    print("Cannot determine current State")
}


// enumeration syntax from swift documentation
enum CompassPoint{
    case north, south, east, west
}

enum Planet {
    case mercury, venus, earth, mars, jupiter, saturn, uranus, neptune, pluto
    
}

var directionToHead = CompassPoint.north

switch directionToHead {
case .north:
    print("May the moon be with you")

case .east:
    print("May the sun be with you")
    
case .south:
    print("May the oceans be with you")
    
case .west:
    print("You are heading wild wild west, Be Aware !!")
}
