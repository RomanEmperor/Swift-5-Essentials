import UIKit

// Error:  A type representing an error value that can be thrown.

// Declaration
//protocol Error{
///* Any type that declares conformance to the Error Protocol can be used to represent an error in Swift's error handling system.
//  The Error Protocol has no requirements of its own, you can declare conformace on any custom type you create  */
//
//}

// Enumerations as Errors
/* Swift's Enumerations are well suited to represent simple errors because they have fixed number of options.
 Create an enumeration that conforms to the Error protocol with a case for each possible error.
 If there are additional details about the error that could be helpful for recovery use associated values to inlude that information.
*/

enum DataError: Error {
    case EmptyPath
    case InvalidPath
}

let playerDataPath = "example/data.txt"

// throwing functions
func loadData(path: String) throws -> Bool? {
    
    guard path.contains("/") else {
        throw DataError.InvalidPath
    }
    guard !path.isEmpty else {
        throw DataError.EmptyPath
    }
    return true
}

// Do-catch statements

//prefixing the function call with keyword "try" in attempts to call a function that throws an error is practise one should follow.
do {
    try loadData(path: playerDataPath)
    // if sucessfully executed
    print("data fetch completed sucessfully")
    
} catch is DataError { // catch works like switch case, it has executable body of its own
    print("Invalid or Empty path detected ...")
    
} catch {
    print("Unknown Error detected")
}


// function loadData can return a value or throw an error, adding a question mark after "try" - keyword tells the compiler that if an error is thrown the return value is nil, Otherwise it's an optional an unwraps normally.

if let dataLoaded = try? loadData(path: playerDataPath){
    print("Data fetch went just file...\(dataLoaded)")
}



// Propagating errors - passing error to other functions

//
func propagateDataError () throws {
    try loadData(path: playerDataPath)
}
do {
    try propagateDataError()
    // if that succeds
    print("Propagated data fetch sucessful!..")
}catch DataError.EmptyPath{
    print("Empty path to data....")
}catch DataError.InvalidPath{
    print("Provided path is invalid")
}catch{
    print("Unknown error detected")
}


