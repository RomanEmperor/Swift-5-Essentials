import UIKit

var str = "Structure and Class in swift"

struct Resolution{
    // The structure has two stored properties width and height of type integer.
    // Stored properties are constants or variables that are bundled up and stored as part of the structure or class.
   var width = 0
    var height = 0
}
class VideoMode
{
    // variable resolution is initalized with a new Resolution structure instance, which infers a property type of Resolution structure.
    var resolution = Resolution()
    
    var interlaced = false
    var frameRate = 0.0
    var name: String? // optional string type is automatically assigned a default value "nil"
}
// MARK: Creating Instances

let someResolution = Resolution()
let someVideoMode = VideoMode()
// Accessing Properties
// we can access the propreties of an instance using a dot(.) syntax

print("the width of resolution is: \(someResolution.width)")

print("The width of some video mode is : \(someVideoMode.resolution.width) \n")

// We can also assign new value to variable property
someVideoMode.resolution.width = 1280
someVideoMode.resolution.height = 1024

print("Now the width of some video mode is: \(someVideoMode.resolution.width) And")
print("The updated height of someVideo mode is: \(someVideoMode.resolution.height)")

/* MARK: - value type and reference type
 
A value type is a type whose value is copied when it's assigned
 to a variable or constant, or when it's passed to a function.
 Integers, floating point numbers, Booleans, strings, arrays and dictionaries are value types and are implemented as structures behind the scenes.
 All Structures and Enumerations are value types in swift.
 That means: any structure and enumerations instances you create
 and any value types they have as properties are always copied when they are passed around in your code.
 */

let hd = Resolution(width: 1920, height: 1080)
var cinema = hd
// Even though hd and cinema now have the same width and height,
// they are two completly different instances behind the scenes

cinema.width = 2048
print("Cinema is now \(cinema.width) pixels wide where as hd has \(hd.width) pixels width")

// Similiar behaviour is shown by enumerations as well:

enum CompassPoint{
    case north, south, east, west
    mutating func turnNorth(){
        self  = .north
    }
}
var currentDirection = CompassPoint.west

let rememberedDirection = currentDirection

currentDirection.turnNorth()

print("The current direction is \(currentDirection) where as the remembered direction is \(rememberedDirection)")

// Classes are reference types
/* Unlike value types, reference types are not copied when they
 are assigned to a variable or constant, or when they are
 passed to a function. Rather than a copy, a reference to the
 same existing instance is used such that updating one instance
 somewhere in the code updates all other occurence of the
 instances */
let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0

print("Frame Rate of TenEighty: \(tenEighty.frameRate)")
print("Frame rate of also ten eighty : \(alsoTenEighty.frameRate)")

// Identity Operators
/*
 To find out weather two constants or variables refer to exact
 the same instance of class or not swift provides two identity
 operators
 i. identical to ===
 ii. Not identical to !===
 */
if tenEighty === alsoTenEighty{
    print("Both refer to same instance")
}

// Revisiting calsses with game logic
// Declaring a new class
class Adventurer{
    
    var name: String
    let maxHelath: Int
    
    var specialMove: String? // optional special Move
    
    // initilizer function
    // The purpose of initilizer is to set all non-optional values when an adventurer instance is created.
    init(name: String, maxHP: Int) { // the parameters of initilizer function must match the non-optional values.
        
        // the job of initilizers is to set properties
        self.name = name
        self.maxHelath = maxHP
    }
    
    // concenience intitilizer
    convenience init(name: String){
        self.init(name:name, maxHP:100)
    }
    
    func printStats() {
        print("Character: \(self.name), Max Health: \(self.maxHelath)")
    }
}

var player1 = Adventurer(name: "Harrison", maxHP: 99)
var player2 = Adventurer(name: "steven")

// showing  reference type properties of a class
var defaultPlayer = player1
defaultPlayer.name = "Bob the Noob"

player1.printStats()
player2.printStats()

