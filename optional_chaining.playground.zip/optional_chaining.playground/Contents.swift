import UIKit
/* MARK: - Optional chaining
 Ehile optionals can be a tricky thing to understand, the rules at least are consistent across Swift Language.
 Get comfortable with them, and optionals will be you new best firend.
 */

struct Item{
    var description: String
    var previousOwner: Owner?
    
}

struct Owner{
    var name: String
    
    // function in oprional chaining retuns an optional as well
    func returnOwnerInfo() -> String {
        return "\(name) is the original owner of the item"
    }
}

var questionDirectory = [
    "Fetch Gemstones": [
        "Objective": "Retrive 5 gemstones",
        "Secret": "Complete in under 5 minutes"
    ],
    "Defeat Big Boss": [
        "Objective": "Beat the ultimate Boss",
        "Secret": "Win with at least 50% health left"
    ]
]

// Creatin Optional chain
var rareDragger = Item(description: "A unique dragger of unknown origin", previousOwner: nil)
var draggerOwner = Owner(name: "Aladdin")
rareDragger.previousOwner = draggerOwner


// creating a computational constant owner that stores the name of previous owner which is optional.
if let owner = rareDragger.previousOwner?.name{
    // the optional here is telling the compilier to return nill if previous owner is nil, and not to bother with trying to get name property of something that doesnot exist
    print("This item used to be owned by \(owner)")
    
}else{
    print("Looks like the histroy of item is unknown...")
}


if let ownerInfo = rareDragger.previousOwner?.returnOwnerInfo(){
    print("Owner found \(ownerInfo)" );
}else{
    print("NO owner was found in the database...")
}

if let gemstoneObjective = questionDirectory["Fetch Gemstones"]?["Objective"]{
    print(gemstoneObjective)
}else{
    
}
