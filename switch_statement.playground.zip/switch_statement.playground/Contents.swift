
//
let initial = "H"
let hp = 240
let mp = 15



// simple switch case
switch initial {
case "H":
    print("This is capital H")
    
case "h":
    print("This is small h")
    
    // switch statement must be exhaustive, meaning there must be some default case to fall back as it can have infinite number of cases.
default:
    print("Here we are by default")
}

// some what complex switch
// switch cases can be defined with ranges and multiple values
switch (mp, hp) {
    // using patterns
case (15, 10):
    print("this is a pattern")
    // using range
case (1...15, 20..<25):
    print("Ranges are the best")
    // value binding with local variable
case (let localMP, let localHP) where localMP + localHP > 20:
    print(localHP, localMP)
    
default:
    print("here the defalut guy")
}




