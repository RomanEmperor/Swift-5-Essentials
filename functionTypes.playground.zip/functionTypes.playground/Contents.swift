/*Function Types

Topic Essentials

Every Functions has a type, or unique signature. Function types can be used in swift like any other type such as string, or integers.
 This can come handy when you need to pass functions into other function as parameters, or use them as return type.

Objectives

*Create a function that takes in an integer, multiplies it by 4 and returns it
*Create another function that takes an integer and a function as parameters

 */

// Function types
// Creating a function that takes in an integer, multiplies it by 4 and returns it
func computeBonusDamage(baseDamage: Int) -> Int{
    return baseDamage*4
}
// the type signature of the function is (Int) -> Int

func dealDamage(baseDamage:Int, bonusDamage: (Int) -> Int){
    let bonus = bonusDamage(baseDamage)
    print("Base Damage \(baseDamage) \n Bonus damage: \(bonus)")
    
}

dealDamage(baseDamage: 5, bonusDamage: computeBonusDamage)

