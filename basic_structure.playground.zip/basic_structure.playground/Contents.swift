import UIKit
/* MARK: - BASIC STRUCTURES */

struct Level{
    let levelID: Int
    var levelObjective: [String]
    
    var levelDescription: String{
        return "Level ID: \(self.levelID)"
    }
    
    // Manual initilizer for structure
    // Better stick with auo generated initilizers
    init(id: Int, objectives: [String]) {
        self.levelID = id
        self.levelObjective = objectives
    }
    // declaring a function in structure is same as in classes, provided that, the function
    // doesnot attempt to change structure properties directly
    func queryObjectives(){
        for obj in levelObjective{
            print("\(obj)")
        }
    }
    
    
    
    mutating func completeObjective(index: Int){
        levelObjective.remove(at: index)
    }
    
  
    
}

var objectives = ["find the lost cat", "Collect all gem stones", "defeat the big boss"]
var level1 = Level(id: 1, objectives: objectives)


// value types

var defaultLevel = level1

level1.completeObjective(index: 0) // marks as index 0 objective has been completed
level1.queryObjectives() // now while querying the objectives, only objectives are shown as one at index 0 has been completed sucessfully.

// however, assigning default level to level1, default level still has all objectives left
defaultLevel.queryObjectives()
