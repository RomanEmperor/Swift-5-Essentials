// Using for- in loops
/* For in loops are primarily to iterate, or loop through  collections, sequences, that can be
 array items, dictionary key value pair, ranges, and characters in a string.
 
 Here we will iterate though a string, array, dictionary and index ranges.
 */

// Some Test Variables
let playerGreeting = "Hello from Hunter"
let armorType = ["Heavy plate", "Hunter Gear", "Mage Robes"]
let weapons = ["longsword": 150, "Dragger": 35, "Mac": 76]

// Looping through Strings
for stringCharacter in playerGreeting {
    print(stringCharacter)
}

// Looping through Arrays
for armors in armorType {
    print(armors)
}

// looping through dictionaries keys
for weaponKey in weapons.keys {
    print(weaponKey)
}

// Similarly looping through dictionary values
for weaponValues in weapons.values {
    print(weaponValues)
    
}

// The efficient way to loop through keys and values pair at once in a single loop
for (weapon, damage) in weapons {
    print("\(weapon):\(damage)")
}


// using range operator


// A close range:: takes into account the first number of our range i.e.1 and last number i.e 10
for indexNumber in 1...10 {
    // meaning for every indexNumber in one through ten do something
    print(indexNumber)
}


// One sided range
for armor in armorType[0...]{
    // meaning: for every armour in armourTypes starting from the first item [0 indexed] and going till there's no more
    print(armor)
}


// half open range: allows to specity last value is left out
for indexNumber in 1..<10{
    print(indexNumber)
}

// One sided range can also be used with half open range as:
for armor in armorType[..<2]{
    print(armor)
} // BE CAREFUL for RANGE ERROR, if the range indexNumber exceeds the number of items in collection
 print("A better way is :")
// A safe way is to use .count property in these kind of situation as:
for armor in armorType[..<armorType.count]{
    print("\(armor)")
}
