import UIKit
/*  Swift Protocols are essentially group of properties and behaviours that can be adopted by a class, struct or an enum.
 If any class, structure or enum implements a protocol, that class, struct or enum enters into a agreement that says they will follow the blueprint the protocol has set out.
 
 Protocols can have properties and function declaration.
 They cannot have stored values and implementation
 It is up to protocol adopting calss or struct to implement it case by case basis.
 
 */

// Declare a protocol here
protocol Collectable {  // Protocols are named with action Verb by swift community
    // Even though protocols variables cannot store values, they still need to have explicit getter or getters and setters events.
    
    var name: String {get} // makes variable name readonly
    var price: Int {get set} // makes variable price read and wirte
    
    // a function declared inside a protocol donot have any function body,
    // its just the pure signature of the function.
    // The protocol adopting class is responsible for implementing it
    
    func collect() -> Bool
    
    
    // for initilizing a protocol, we do it just like with class.
    // only initilizer function signature, no body at all.
    init(withName: String, startingPrice: Int)
}

// Extending the protocol
extension Collectable{
    var priceIncrease: Int {
        return self.price * 10
    }
    
    init(name: String){
        self.init(withName: name, startingPrice: 100)
    }
    
    func collect() -> Bool{
        print("Default item couldn't be collected...")
        return false
    }
    
}



// declaring another protocol

protocol  Usable{
    func use()
}

// Protocol adoption
// declare a class or sturcture of type protocol defined earlier, an eror pops up with a fix

class Item: Collectable, Usable {
    
 
    // adopting multiple protocols
    
    /* a few things to note
    1 - variables and functions inforced by a protocol are written the exact same way.
    2 - If you are using an inti function in your protocol, its going to be "required" in the adopting class.
     */
    
    var name: String
    var price: Int
//
//    func collect() -> Bool {
//        print("Item collected !")
//        return true
//    }
    
    func use() {
        print("Item used !! ")
    }
    
    required init(withName: String, startingPrice: Int) {
        self.name = withName
        self.price = startingPrice
    }
    
}

// creating an instance of class
let potion = Item(withName: "High Potion", startingPrice: 35)
potion.collect()
potion.use()

let sercredGames = Item(name: "Technotip")
sercredGames.price



// Exdending inbult Swift class - string

extension String {
    func fancyDebug (){
        print("This string has \(self.count) characters")
    }
}

sercredGames.name.fancyDebug()

/* There is no upper limit on how many protocol can an object adopt.
 This lets you build up classes, structs or enums from different functional pieces.
 This is huge step in efficiency over an object oriented single inherientence approach
 As different objects adopting the same protocol can have their own implementation while following the same bueprint structure.
 */

// Protocol Oriented programming in swift is huge subject in itself. It can be used to build Modular and flexiable application architectures.
