import UIKit
/* Subclassing in swift
 Subclassing is a great way to expand the flexibility of your custom classes that share the functionality of a parent class.
 */

class Adventurer{
    var name: String
    var specialMove: String?
    var maxHealth: Int
    
    // computed property
    var healthLost: Int { // health lost is a computed variable which is a mix between a variable and function
        return  maxHealth - health
    }
    
    static var maxActivePlayers = 10
    
    class var credo: String {
        return "Defend the helpless"
    }
    
    fileprivate var health: Int
    var Health: Int{
        get {
            return health
        }
        set{
            if(newValue <= 100){
                health = newValue
            }
        }
    }
    
    
    init(name: String, maxHP: Int) {
        self.name = name
        self.maxHealth = maxHP
        self.health = maxHP
    }
    
    convenience init(name: String){
        self.init(name: name, maxHP: 100)
    }
    
    func printStats() {
        print("Character: \(self.name), Health: \(self.health) / \(self.maxHealth)")
    }
    
}



// Subclass
// Here we are creating Ranger - a subclass of Adventurer and will be changing some of its properties

class Ranger: Adventurer {
    
    // depending on the access level of parent class, a subclass can have access to its properties, methods, and other entities.
    // In this case, Ranger is going to inherent name, specialMove, maxHealth and other computed properties. So, there is no code duplication required, thanks to inheritance.
    
    // Subclass can have unique properties that the parent class doesn't have.
    /* Anyhting declared in the subclass is not accessible to parent class*/
    var classAdvantage: String
    
    // Overriding
    override class var credo: String{
        return "to the king!"
    }
    
    init(name: String, advantage: String){
        self.classAdvantage = advantage
        super.init(name: name, maxHP: 150)
        
    }
    
    // function override
    override func printStats() {
        print("\(self.name): Ranger, Advantage: \(self.classAdvantage)")
    }
}

var player1 = Adventurer(name: "harrission", maxHP: 99)
var player2 = Adventurer(name: "steven")

player2.printStats()
player1.printStats()

Adventurer.credo
Adventurer.maxActivePlayers
Ranger.credo

var aragon = Ranger(name: "Aragon", advantage: "Stealth")
aragon.printStats()

